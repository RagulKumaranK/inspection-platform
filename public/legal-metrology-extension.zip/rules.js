// rules.js
const ComplianceRules = {
  requiredFields: [
    { id: 'mrp', label: 'MRP (Maximum Retail Price)', keywords: ['mrp', 'price', 'retail price'] },
    { id: 'net_quantity', label: 'Net Quantity', keywords: ['net quantity', 'net weight', 'volume', 'count'] },
    { id: 'manufacturer', label: 'Manufacturer Details', keywords: ['manufacturer', 'manufactured by', 'packer', 'marketed by'] },
    { id: 'country_of_origin', label: 'Country of Origin', keywords: ['country of origin', 'origin', 'made in'] },
    { id: 'customer_care', label: 'Customer Care Details', keywords: ['customer care', 'consumer care', 'support', 'help', 'contact'] }
  ],

  checkCompliance: (data) => {
    const results = [];
    let compliantCount = 0;

    ComplianceRules.requiredFields.forEach(field => {
      const isPresent = data[field.id] && data[field.id].length > 0;
      if (isPresent) compliantCount++;

      results.push({
        id: field.id,
        label: field.label,
        status: isPresent ? 'pass' : 'fail',
        value: isPresent ? data[field.id] : 'Not found'
      });
    });

    const isCompliant = compliantCount === ComplianceRules.requiredFields.length;

    return {
      isCompliant,
      score: Math.round((compliantCount / ComplianceRules.requiredFields.length) * 100),
      details: results
    };
  }
};
