// content.js
(async () => {
    // Debugging: Check if Tesseract is in window
    console.log("LMCS Extension: Window keys starting with T:", Object.keys(window).filter(k => k.startsWith('T')));

    const Tesseract = window.Tesseract;

    if (!Tesseract) {
        console.error("LMCS Extension: Tesseract library not found on window object.");
        // We don't return here anymore to allow text-only analysis if Tesseract fails
    } else {
        console.log("LMCS Extension: Tesseract loaded from window");
    }

    async function performOCR(imageUrl) {
        if (!Tesseract) return "";
        console.log("LMCS Extension: Performing OCR on", imageUrl);
        try {
            const worker = await Tesseract.createWorker({
                workerPath: chrome.runtime.getURL('worker.min.js'),
                corePath: chrome.runtime.getURL('tesseract-core.wasm.js'),
                logger: m => console.log("ClearTag OCR:", m)
            });

            await worker.loadLanguage('eng');
            await worker.initialize('eng');
            const { data: { text } } = await worker.recognize(imageUrl);
            await worker.terminate();
            console.log("LMCS Extension: OCR Result:", text);
            return text;
        } catch (e) {
            console.error("LMCS Extension: OCR Failed", e);
            return "";
        }
    }

    async function scrapePage() {
        // Flipkart Support: Expand "Manufacturing, Packaging and Import Info"
        if (window.location.hostname.includes('flipkart.com')) {
            console.log("LMCS Extension: Detected Flipkart, attempting to expand details...");
            const links = Array.from(document.querySelectorAll('div, span, a, li'));
            const detailsLink = links.find(el => el.innerText && el.innerText.trim() === 'Manufacturing, Packaging and Import Info');

            if (detailsLink) {
                console.log("LMCS Extension: Found details link, clicking...");
                detailsLink.click();
                // Wait for modal to open
                await new Promise(resolve => setTimeout(resolve, 1500));
            }
        }

        // Meesho Support: Expand "Additional Details" and "More Information"
        let meeshoData = {};
        if (window.location.hostname.includes('meesho.com')) {
            console.log("LMCS Extension: Detected Meesho, attempting to expand details...");

            const expandSection = async (name) => {
                const links = Array.from(document.querySelectorAll('span, div, p, h6'));
                const link = links.find(el => el.innerText && el.innerText.trim() === name);
                if (link) {
                    console.log(`LMCS Extension: Found ${name}, clicking...`);
                    link.click();
                    await new Promise(resolve => setTimeout(resolve, 1000));
                    return true;
                }
                return false;
            };

            await expandSection('Additional Details');
            await expandSection('More Information');

            // Structured extraction for Meesho
            const extractField = (regex) => {
                // Search in the whole body text for simplicity and coverage
                const matches = document.body.innerText.match(regex);
                return matches ? matches[1].trim() : null;
            };

            // Specific Meesho patterns
            // Net Quantity (N): 2
            meeshoData.net_quantity = extractField(/Net Quantity(?: \(N\))?\s*[:\-]?\s*([^\n]+)/i);
            // Manufacturer Details : ...
            meeshoData.manufacturer = extractField(/(?:Manufacturer|Packer|Importer) Details\s*[:\-]?\s*([^\n]+)/i);
            // Country of Origin : India
            meeshoData.country_of_origin = extractField(/Country of Origin\s*[:\-]?\s*([^\n]+)/i);

            // Fallback for sizes if net quantity is missing
            const sizes = extractField(/Sizes\s*[:\-]?\s*([^\n]+)/i);
            if (sizes && !meeshoData.net_quantity) {
                meeshoData.net_quantity = sizes;
            }
        }

        const textContent = document.body.innerText;
        let combinedText = textContent.toLowerCase();

        // Image OCR
        const imageUrls = new Set();

        // Generic large images
        document.querySelectorAll('img').forEach(img => {
            const rect = img.getBoundingClientRect();
            if (rect.width > 150 && rect.height > 150 && img.src) {
                imageUrls.add(img.src);
            }
        });

        // Amazon specific
        document.querySelectorAll('img').forEach(img => {
            if (img.getAttribute('data-old-hires')) {
                imageUrls.add(img.getAttribute('data-old-hires'));
            }
            const dynamic = img.getAttribute('data-a-dynamic-image');
            if (dynamic) {
                try {
                    const urls = JSON.parse(dynamic);
                    Object.keys(urls).forEach(url => imageUrls.add(url));
                } catch (e) { }
            }
        });

        const imagesToScan = Array.from(imageUrls).slice(0, 5); // Limit to 5 unique images
        console.log("LMCS Extension: Scanning images:", imagesToScan);

        for (const url of imagesToScan) {
            const ocrText = await performOCR(url);
            combinedText += " " + ocrText.toLowerCase();
        }

        // Helper to find text near keywords
        const findValue = (keywords) => {
            // Try JSON-LD first
            const jsonLd = Array.from(document.querySelectorAll('script[type="application/ld+json"]'));
            for (const script of jsonLd) {
                try {
                    const data = JSON.parse(script.innerText);
                    const str = JSON.stringify(data).toLowerCase();
                    // This is a weak check, ideally we parse the JSON structure, but for now we just look for presence
                    // in the JSON string if we can't find it in text.
                } catch (e) { }
            }

            for (const keyword of keywords) {
                const index = combinedText.indexOf(keyword);
                if (index !== -1) {
                    // Extract a snippet around the keyword
                    const snippet = combinedText.substring(index, index + 200).replace(/\s+/g, ' ').trim();
                    return snippet;
                }
            }
            return null;
        };

        const data = {
            mrp: findValue(['mrp', 'maximum retail price', '₹', 'rs.']),
            net_quantity: meeshoData.net_quantity || findValue(['net quantity', 'net weight', 'count', 'vol', 'content']),
            manufacturer: meeshoData.manufacturer || findValue(['manufactured by', 'manufacturer', 'packer', 'marketed by']),
            country_of_origin: meeshoData.country_of_origin || findValue(['country of origin', 'made in', 'origin']),
            customer_care: findValue(['customer care', 'consumer care', 'contact us', 'support', 'help line', 'feedback'])
        };

        if (data.mrp && !/\d/.test(data.mrp)) data.mrp = null;

        return data;
    }

    // Listen for messages from popup
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === "analyze") {
            scrapePage().then(data => {
                sendResponse({ data });
            });
            return true; // Keep channel open for async response
        }
    });
})();
